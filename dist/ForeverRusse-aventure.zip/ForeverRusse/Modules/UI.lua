local _, A = ...
local function label(parent, x,y,w,text,template)
    local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlight")
    A:ApplyFont(f)
    f:SetPoint("TOPLEFT",x,y); f:SetWidth(w); f:SetJustifyH("LEFT"); f:SetJustifyV("TOP"); f:SetText(text or ""); return f
end
local function button(parent,x,y,w,h,text,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate"); b:SetSize(w,h); b:SetPoint("TOPLEFT",x,y); A:ApplyButtonFonts(b); b:SetText(text); b:SetScript("OnClick",fn); return b
end
local function scroll(parent,x,y,w,h)
    local s=CreateFrame("ScrollFrame",nil,parent,"UIPanelScrollFrameTemplate"); s:SetPoint("TOPLEFT",x,y); s:SetSize(w,h)
    local child=CreateFrame("Frame",nil,s); child:SetSize(w-8,h); s:SetScrollChild(child); return s,child
end
local function textBlock(parent,text,w)
    local f=label(parent,0,0,w,text); f:SetSpacing(4); return f
end
local function setBlock(child,f,text,minHeight)
    f:SetText(text); child:SetHeight(math.max(minHeight or 1,f:GetStringHeight()+20))
end
local function start(A, kind, introduce)
    local active, starters = A:StartAdventure(kind, introduce)
    A.adventureIntro = starters and {kind=kind,words=starters} or nil
    A:RefreshAdventure()
    return active
end

function A:RefreshAdventureNotice()
    if not self.db then return end
    local state = self:AdventureState()
    local show = ((state.tickets or 0)>0 or state.active ~= nil)
        and not self:Combat() and not (self.frame and self.frame:IsShown())
    if not self.adventureNotice and show then
        local notice = CreateFrame("Button",nil,UIParent,"UIPanelButtonTemplate")
        notice:SetSize(140,28)
        notice:SetPoint("TOPRIGHT",-32,-228)
        A:ApplyButtonFonts(notice)
        notice:SetScript("OnClick",function() A:ShowTab("adventure") end)
        self.adventureNotice = notice
    end
    if self.adventureNotice then
        self.adventureNotice:SetText(state.active and "Reprendre" or "Défi de quête")
        self.adventureNotice:SetShown(show)
    end
end

local function refreshOnReset(A, state)
    if A.adventureTimer then A.adventureTimer:Cancel(); A.adventureTimer=nil end
    if not C_Timer or not C_Timer.NewTimer then return end
    local now = A:Now()
    local nextChange
    for _, key in ipairs({"dailyUntil","bonusUntil","bonusOffer"}) do
        local expiry = state[key]
        if expiry and expiry > now and (not nextChange or expiry < nextChange) then nextChange=expiry end
    end
    if nextChange then
        A.adventureTimer = C_Timer.NewTimer(nextChange-now+1,function()
            A.adventureTimer=nil
            A:RefreshAdventure()
        end)
    end
end

function A:RefreshAdventure()
    if not self.frame or self.tab ~= "adventure" or not self.frame:IsShown() then return end
    local state = self:AdventureState()
    local ui = self.adventureUI
    local level,xp,cap,words,mastered = self:AdventureProgress()
    ui.level:SetText(("Niveau %d"):format(level))
    ui.xp:SetMinMaxValues(0,cap)
    ui.xp:SetValue(xp)
    ui.xpText:SetText(("%d / %d XP"):format(xp,cap))
    ui.words:SetText(("%d / %d mots rencontrés · %d acquis"):format(words,#self.adventurePool,mastered))

    local active, intro = state.active, self.adventureIntro
    ui.home:SetShown(not active and not intro)
    ui.quiz:SetShown(active ~= nil)
    ui.intro:SetShown(intro ~= nil and not active)
    if active then
        local q = active.questions[active.index]
        local category = q.reverse and "Quel mot russe ?" or q.kind == "letter" and "Comment se lit cette lettre ?" or "Quel est le sens ?"
        ui.questionNumber:SetText(("%d / %d   %s"):format(active.index,#active.questions,category))
        ui.prompt:SetText(q.reverse and q.prompt or self:RussianDisplay(q.prompt))
        for i,b in ipairs(ui.answers) do
            b.choice = q.choices[i]
            b:SetShown(b.choice ~= nil)
            b:SetEnabled(active.answer == nil)
            local color
            if active.answer and b.choice == q.correct then color = "|cff8fdf9f"
            elseif active.answer and b.choice == active.answer then color = "|cffffa29b" end
            local choice = b.choice or ""
            if q.reverse then choice = self:RussianDisplay(choice) end
            b:SetText((color or "")..choice..(color and "|r" or ""))
        end
        local feedback = ""
        if active.answer then
            if active.answer == q.correct then feedback = "|cff8fdf9fCorrect !|r"
            else feedback = "Réponse : "..(q.reverse and self:RussianDisplay(q.correct) or q.correct).." · à revoir" end
        end
        ui.feedback:SetText(feedback)
        ui.next:SetShown(active.answer ~= nil)
        ui.next:SetText(active.index == #active.questions and "Terminer" or "Suivant")
    elseif intro then
        local lines = {}
        for _, word in ipairs(intro.words) do lines[#lines+1] = self:RussianDisplay(word.ru).." — "..word.fr end
        ui.introWords:SetText(table.concat(lines,"\n"))
    else
        local quest,daily,bonus = self:AdventureAvailability()
        ui.quest:SetEnabled(not not quest)
        ui.quest:SetText(quest and ("Défi de quête (%d)"):format(state.tickets) or "Défi de quête")
        ui.daily:SetEnabled(not not daily)
        ui.daily:SetText(daily and "Défi quotidien" or "Quotidien indisponible")
        ui.bonus:SetShown(not not bonus)
        local summary = state.summary
        if summary then
            ui.summary:SetText(("%d / %d bonnes réponses · +%d XP"):format(summary.score,summary.total,summary.reward))
        elseif not quest then
            ui.summary:SetText("Rends une quête pour débloquer un défi.")
        else
            ui.summary:SetText("3 mots · 2 lettres")
        end
    end
    self:RefreshAdventureNotice()
    refreshOnReset(self,state)
end

local function page(parent)
    local p = CreateFrame("Frame",nil,parent)
    p:SetPoint("TOPLEFT",24,-111)
    p:SetSize(442,282)
    return p
end

local displaySettings = {
    {"Infobulles d’objets", "tooltips"},
    {"Infobulles de sorts", "spells"},
    {"Infobulles de PNJ", "units"},
    {"Parchemin de quête automatique", "questCompanion"},
    {"Russe sous le titre", "tooltipBelowTitle"},
    {"Coloration des lettres", "colorLetters"},
    {"Aides de prononciation", "hints"},
    {"Translittération latine", "phoneticLatin"},
}

local function showSettings(A)
    if not A.displaySettings then
        local pane = page(A.frame)
        pane:SetPoint("TOPLEFT",24,-58)
        local checks = {}
        for i, setting in ipairs(displaySettings) do
            local title, key = unpack(setting)
            local y = -(i-1)*35
            local check = CreateFrame("CheckButton",nil,pane,"UICheckButtonTemplate")
            check:SetPoint("TOPLEFT",0,y)
            label(pane,31,y-9,403,title)
            check:SetScript("OnClick",function(b)
                local enabled = not not b:GetChecked()
                A.db.settings[key] = enabled
                if key == "questCompanion" then A.db.settings.quests = enabled end
            end)
            checks[key] = check
        end
        A.displaySettings = {pane=pane,checks=checks}
    end
    for key, check in pairs(A.displaySettings.checks) do
        check:SetChecked(A:On(key) and (key ~= "questCompanion" or A:On("quests")))
    end
    A.displaySettings.pane:Show()
end

function A:BuildUI()
    if self.frame then return end
    local f = CreateFrame("Frame","ForeverRussePanel",UIParent,"BackdropTemplate")
    f:Hide()
    f:SetSize(490,424)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving)
    f:SetScript("OnDragStop",f.StopMovingOrSizing)
    f:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true,tileSize=32,edgeSize=24,
        insets={left=5,right=5,top=5,bottom=5},
    })
    f:SetBackdropColor(.06,.08,.12,.97)
    f:SetScript("OnHide",function()
        if A.adventureTimer then A.adventureTimer:Cancel(); A.adventureTimer=nil end
        A:RefreshAdventureNotice()
    end)
    self.frame = f
    if UISpecialFrames then table.insert(UISpecialFrames,"ForeverRussePanel") end
    local close = CreateFrame("Button",nil,f,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",-3,-3)
    self.adventureHeading = label(f,24,-18,285,"Aventure","GameFontNormalLarge")
    self.displayButton = button(f,337,-13,110,26,"Affichage",function()
        A:ShowTab(A.tab == "display" and "adventure" or "display")
    end)

    local root = CreateFrame("Frame",nil,f)
    root:SetAllPoints(f)
    local ui = {root=root}
    self.adventureUI = ui
    ui.level = label(root,24,-52,100,"")
    ui.words = label(root,24,-80,430,"")
    ui.xp = CreateFrame("StatusBar",nil,root)
    ui.xp:SetPoint("TOPLEFT",115,-50)
    ui.xp:SetSize(350,19)
    ui.xp:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    ui.xp:SetStatusBarColor(.52,.37,.86)
    local background = ui.xp:CreateTexture(nil,"BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(.17,.16,.22,.95)
    ui.xpText = label(ui.xp,0,-3,350,"")
    ui.xpText:SetJustifyH("CENTER")

    ui.home = page(root)
    ui.summary = label(ui.home,0,-10,442,"","GameFontNormalLarge")
    ui.quest = button(ui.home,0,-58,210,33,"Défi de quête",function() start(A,"quest") end)
    ui.daily = button(ui.home,223,-58,219,33,"Défi quotidien",function() start(A,"daily") end)
    ui.bonus = button(ui.home,0,-103,210,30,"Exercice bonus",function() start(A,"bonus") end)

    ui.quiz = page(root)
    ui.questionNumber = label(ui.quiz,0,0,442,"")
    ui.prompt = label(ui.quiz,0,-24,442,"","GameFontNormalLarge")
    ui.answers = {}
    for i=1,4 do
        ui.answers[i] = button(ui.quiz,0,-60-(i-1)*34,442,30,"",function(b)
            A:AnswerAdventure(b.choice)
            A:RefreshAdventure()
        end)
    end
    ui.feedback = label(ui.quiz,0,-209,442,"")
    ui.next = button(ui.quiz,292,-238,150,30,"Suivant",function()
        A:AdvanceAdventure()
        A:RefreshAdventure()
    end)

    ui.intro = page(root)
    label(ui.intro,0,0,442,"Premiers mots","GameFontNormalLarge")
    ui.introWords = label(ui.intro,0,-42,442,"")
    ui.introWords:SetSpacing(8)
    button(ui.intro,0,-158,140,30,"Retour",function()
        A.adventureIntro = nil
        A:RefreshAdventure()
    end)
    ui.begin = button(ui.intro,292,-158,150,30,"Commencer",function()
        start(A,A.adventureIntro.kind,true)
    end)
end

function A:ShowTab(tab)
    if self:Combat() then return end
    if not self.frame then self:BuildUI() end
    local diagnostic = tab == "fonttest" or tab == "phoneticExport"
    local settings = tab == "display"
    self.tab = (diagnostic or settings) and tab or "adventure"
    self.adventureHeading:SetText(tab == "fonttest" and "Test de police"
        or tab == "phoneticExport" and "Formes manquantes" or settings and "Affichage" or "Aventure")
    self.displayButton:SetShown(not diagnostic)
    self.displayButton:SetText(settings and "Aventure" or "Affichage")
    self.adventureUI.root:SetShown(not (diagnostic or settings))
    if settings then showSettings(self)
    elseif self.displaySettings then self.displaySettings.pane:Hide() end
    if diagnostic then
        if not self.adventureDiagnostic then
            local pane = page(self.frame)
            pane:SetPoint("TOPLEFT",24,-58)
            local diagnostic, child = scroll(pane,0,0,438,306)
            local edit=CreateFrame("EditBox",nil,child)
            edit:SetPoint("TOPLEFT"); edit:SetWidth(402); edit:SetMultiLine(true)
            edit:SetFontObject(GameFontHighlight); self:ApplyFont(edit); edit:SetAutoFocus(false)
            edit:SetScript("OnEscapePressed",function(box) box:ClearFocus() end)
            edit:SetScript("OnEditFocusGained",function(box) box:HighlightText() end)
            button(pane,0,-315,120,28,"Aventure",function() A:ShowTab("adventure") end)
            self.adventureDiagnostic = {pane=pane,scroll=diagnostic,child=child,edit=edit}
        end
        local diag = self.adventureDiagnostic
        local text = self.tab == "fonttest" and self:FontSamples() or table.concat(self:MissingPronunciations(),"\n")
        local _, lines = text:gsub("\n", "")
        diag.edit:SetText(text)
        diag.edit:SetHeight(math.max(294,(lines+1)*36))
        diag.child:SetHeight(diag.edit:GetHeight()+4)
        diag.scroll:SetVerticalScroll(0)
        diag.pane:Show()
    elseif self.adventureDiagnostic then
        self.adventureDiagnostic.pane:Hide()
    end
    self.frame:Show()
    self:RefreshAdventure()
    self:RefreshAdventureNotice()
end

local function renderQuest(panel)
    local text,tips = A:QuestReadingText(panel.reading, panel.compare, panel.details)
    setBlock(panel.body, panel.text, text, panel.scroll:GetHeight())
    for _, tip in ipairs(tips or {}) do
        A:RecordAdventureWord(tip[8],tip[4],tip[6],tip[9])
    end
    A:RefreshAdventure()
    panel.scroll:SetVerticalScroll(0)
    panel.compareButton:SetText(panel.compare and "Masquer le français" or "Comparer en français")
end

function A:ShowQuestReading(reading, anchor)
    if self:Combat() then return end
    local panel = self.questPanel
    if not panel then
        panel = CreateFrame("Frame", "ForeverRusseQuestPanel", UIParent, "BackdropTemplate")
        panel:Hide()
        panel:SetFrameStrata("DIALOG")
        panel:SetClampedToScreen(true)
        panel:EnableMouse(true)
        panel:SetBackdrop({
            bgFile="Interface\\Buttons\\WHITE8X8",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
            edgeSize=22, insets={left=5,right=5,top=5,bottom=5},
        })
        panel:SetBackdropColor(.95,.85,.66,1)
        panel:SetBackdropBorderColor(.61,.43,.23,1)
        panel.heading = label(panel,19,-16,250,"","GameFontNormalLarge")
        panel.heading:SetTextColor(.25,.13,.06)
        local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT",-4,-4)
        panel.compareButton = button(panel,18,-45,180,25,"Comparer en français",function()
            panel.compare = not panel.compare
            renderQuest(panel)
        end)
        panel.detailsButton = button(panel,207,-45,110,25,"Détails",function()
            panel.details = not panel.details
            renderQuest(panel)
        end)
        panel.scroll,panel.body = scroll(panel,19,-83,315,370)
        panel.text = textBlock(panel.body,"",305)
        panel.text:SetTextColor(.25,.13,.06)
        if UISpecialFrames then table.insert(UISpecialFrames,"ForeverRusseQuestPanel") end
        self.questPanel = panel
    end
    panel.reading = reading
    panel.compare, panel.details = false, false
    panel.heading:SetText(reading.options and "Dialogue en russe" or "Quête en russe")
    panel.detailsButton:SetShown(not reading.options)
    self.questAnchor = anchor
    local width = math.min(380, math.max(320, UIParent:GetWidth() * .46))
    local height = math.min(550, UIParent:GetHeight() - 48)
    panel:SetSize(width,height)
    panel.scroll:SetSize(width-51,height-104)
    panel.body:SetWidth(width-51)
    panel.text:SetWidth(width-53)
    panel:ClearAllPoints()
    if anchor then
        local anchorRight = anchor:GetRight()
        local anchorLeft = anchor:GetLeft()
        if anchorRight and UIParent:GetWidth() - anchorRight >= width + 8 then
            panel:SetPoint("TOPLEFT",anchor,"TOPRIGHT",8,0)
        elseif anchorLeft and anchorLeft >= width + 8 then
            panel:SetPoint("TOPRIGHT",anchor,"TOPLEFT",-8,0)
        else
            panel:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-8,-24)
        end
    else
        panel:SetPoint("CENTER")
    end
    panel:Show()
    renderQuest(panel)
end
