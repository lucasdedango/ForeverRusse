local _, A = ...
local XP_PER_LEVEL = 100
local STARTERS = {"вода", "дом", "дорога"}
local related = {
    ["найти"]="trouver", ["искать"]="trouver",
    ["принести"]="livrer", ["отнести"]="livrer", ["доставить"]="livrer",
    ["вернуться"]="revenir", ["возвращаться"]="revenir",
    ["убить"]="tuer", ["уничтожить"]="tuer",
    ["помочь"]="aide", ["помощь"]="aide",
    ["защитить"]="sauver", ["спасти"]="sauver",
    ["получить"]="obtenir", ["добыть"]="obtenir",
}

A.adventureWords, A.adventureForms = {}, {}
for _, word in ipairs(A.adventurePool) do
    A.adventureWords[word.id] = word
    if not word.contextual then
        A.adventureForms[A:Normalize(word.ru)] = {word.id,word.ru,word.fr}
        for form, meaning in pairs(word.forms or {}) do
            A.adventureForms[A:Normalize(form)] = {word.id,form,meaning}
        end
    end
end

local function tableField(owner, key)
    if type(owner[key]) ~= "table" then owner[key] = {} end
    return owner[key]
end

function A:AdventureState()
    local state = tableField(self.db, "adventure")
    tableField(state, "words")
    return state
end

local function character()
    if type(ForeverRusseAdventureCharacterDB) ~= "table" then ForeverRusseAdventureCharacterDB = {} end
    return tableField(ForeverRusseAdventureCharacterDB, "turnedIn")
end

function A:AdventureQuestAccepted(id)
    id = self:ID(id)
    if id then character()[id] = nil end
end

function A:AdventureQuestTurnedIn(id)
    id = self:ID(id)
    if not id or not self.db then return false end
    local completed = character()
    if completed[id] then return false end
    completed[id] = true
    local state = self:AdventureState()
    state.tickets = (state.tickets or 0)+1
    return true
end

function A:RecordAdventureWord(id, ru, fr, context)
    local word = self.adventureWords[id]
    if not word or not self.db then return end
    local words = self:AdventureState().words
    -- Keep the example the player first saw and the same progress for its sense.
    if not words[id] then
        words[id] = {ru=ru or word.ru,fr=fr or word.fr,context=context,streak=0,due=0}
    end
    return words[id]
end

function A:AdventureStarterWords()
    local words = self:AdventureState().words
    local count = 0
    for id in pairs(words) do
        if self.adventureWords[id] then count = count+1 end
    end
    local nextWords = {}
    for _, id in ipairs(STARTERS) do
        if count >= 3 then break end
        if not words[id] then
            nextWords[#nextWords+1] = self.adventureWords[id]
            count = count+1
        end
    end
    return nextWords
end

function A:AdventureReset(now)
    local seconds = self:Safe("adventure:reset", C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset)
    if issecretvalue and issecretvalue(seconds) then return end
    if type(seconds) == "number" and seconds > 0 then return now+math.ceil(seconds) end
end

function A:AdventureAvailability()
    local state, now = self:AdventureState(), self:Now()
    local reset = self:AdventureReset(now)
    return (state.tickets or 0) > 0,
           reset and (state.dailyUntil or 0) <= now,
           reset and (state.bonusOffer or 0) > now and (state.bonusUntil or 0) <= now
end

function A:AdventureProgress()
    local state = self:AdventureState()
    local count, mastered = 0, 0
    for id, card in pairs(state.words) do
        if self.adventureWords[id] then
            count = count+1
            if (card.streak or 0) >= 3 then mastered=mastered+1 end
        end
    end
    local xp = state.xp or 0
    return math.floor(xp/XP_PER_LEVEL)+1, xp%XP_PER_LEVEL, XP_PER_LEVEL, count, mastered
end

local function weight(card, now)
    if not card.lastReview then return 3 end
    if (card.due or 0) > now then return 1 end
    if (card.errors or 0) > 0 and (card.streak or 0) == 0 then return 8 end
    return 4
end

local function draw(pool, now)
    local total = 0
    for _, entry in ipairs(pool) do total = total+weight(entry.card, now) end
    local pick = math.random(total)
    for i, entry in ipairs(pool) do
        pick = pick-weight(entry.card, now)
        if pick <= 0 then return table.remove(pool, i) end
    end
end

local function question(A, entry, distractors, kind, reverse)
    local card = entry.card
    local options, correct = A:Choices(card, distractors, reverse)
    return {id=entry.id, kind=kind, ru=card.ru, fr=card.fr,
            prompt=reverse and card.fr or card.context or card.ru, reverse=reverse,
            choices=options, correct=correct}
end

local function wordCards(A, state)
    local seen = {}
    for _, word in ipairs(A.adventurePool) do
        local card = state.words[word.id]
        if card then seen[#seen+1] = {id=word.id,card=card} end
    end
    return seen
end

local function wordQuestion(A, entry, reverse)
    local options = {}
    local group = A.adventureWords[entry.id].group
    local forbidden = related[entry.id] or entry.id
    for _, word in ipairs(A.adventurePool) do
        if word.group == group and (related[word.id] or word.id) ~= forbidden then
            options[#options+1] = word
        end
    end
    return question(A,entry,options,"word",reverse)
end

local function regularQuestions(A, state, now)
    local questions, letters, letterChoices = {}, {}, {}
    local seen = wordCards(A,state)
    for _ = 1, 3 do
        questions[#questions+1] = wordQuestion(A,draw(seen,now),false)
    end
    for _, letter in ipairs(A.alphabet) do
        local card = A:LetterCard(letter)
        letters[#letters+1] = {id=letter[1],card=card}
        letterChoices[#letterChoices+1] = card
    end
    for _ = 1, 2 do
        questions[#questions+1] = question(A,draw(letters,now),letterChoices,"letter",false)
    end
    return questions
end

local function bonusQuestion(A, state, now)
    if (state.bonuses or 0)%2 == 0 then
        return wordQuestion(A,draw(wordCards(A,state),now),true)
    end
    local pool, options = {}, {}
    for _, row in ipairs(A.vocabulary) do
        if row[3] == "phrase" then
            local card = A:Card(row[1],row[2],row[3],"lexique") or {ru=row[1],fr=row[2]}
            pool[#pool+1] = {id=row[1],card=card}
            options[#options+1] = card
        end
    end
    return question(A,draw(pool,now),options,"phrase",false)
end

function A:StartAdventure(kind, introduce)
    local state, now = self:AdventureState(), self:Now()
    if state.active or self:Combat() then return end
    local quest, daily, bonus = self:AdventureAvailability()
    if not ((kind == "quest" and quest) or (kind == "daily" and daily) or (kind == "bonus" and bonus)) then return end
    local reset = kind ~= "quest" and self:AdventureReset(now) or nil
    if kind ~= "quest" and not reset then return end
    local starters = self:AdventureStarterWords()
    if #starters > 0 and not introduce then return nil, starters end
    for _, word in ipairs(starters) do self:RecordAdventureWord(word.id) end

    local questions = kind == "bonus" and {bonusQuestion(self,state,now)} or regularQuestions(self,state,now)
    if kind == "quest" then state.tickets = state.tickets-1 end
    state.summary = nil
    state.active = {kind=kind, reset=reset, questions=questions, index=1, score=0}
    return state.active
end

function A:AnswerAdventure(choice)
    local state = self:AdventureState()
    local active = state.active
    if not active or active.answer or self:Combat() then return end
    local q = active.questions[active.index]
    local valid
    for _, answer in ipairs(q.choices) do if answer == choice then valid = true; break end end
    if not valid then return end
    local good = choice == q.correct
    local card
    if q.kind == "word" then
        card = state.words[q.id]
    elseif q.kind == "letter" then
        card = self.db.letters[q.id]
    else
        card = self:Card(q.ru,q.fr,"phrase","lexique")
    end
    if card then self:Grade(card,good) end
    active.answer = choice
    if good then active.score = active.score+1 end
    return good
end

function A:AdvanceAdventure()
    local state = self:AdventureState()
    local active = state.active
    if not active or not active.answer or self:Combat() then return end
    if active.index < #active.questions then
        active.index = active.index+1
        active.answer = nil
        return true
    end
    local bonus = active.kind == "bonus"
    local reward = (bonus and 5 or 10)+2*active.score
    state.xp = (state.xp or 0)+reward
    if active.kind == "daily" then state.dailyUntil = active.reset end
    if bonus then
        state.bonusUntil = active.reset
        state.bonuses = (state.bonuses or 0)+1
        state.bonusOffer = nil
    else
        local now = self:Now()
        if (state.bonusUntil or 0) <= now then state.bonusOffer = self:AdventureReset(now) end
    end
    state.summary = {reward=reward, score=active.score, total=#active.questions, kind=active.kind}
    state.active = nil
    return true
end
