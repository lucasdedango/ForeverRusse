local _, A = ...
local acute = "́"
local fields = {"title", "objective", "body"}
local ambiguousCommands = {["поговорите"]=true,["получите"]=true,["защитите"]=true}

local function signature(text)
    local state = 0
    for i = 1, #text do
        state = (131 * state + text:byte(i)) % 2147483647
    end
    return tostring(#text)..":"..tostring(state)
end

local function escape(text)
    return (text:gsub("|", "||"))
end

local function ranges(text, spans)
    table.sort(spans, function(a,b) return a[1] < b[1] end)
    local start = 1
    local out = {}
    for _, span in ipairs(spans) do
        if span[1] >= start then
            out[#out+1] = escape(text:sub(start, span[1]-1))
            out[#out+1] = "|cff22665b"..escape(span[3] or text:sub(span[1], span[2])).."|r"
            start = span[2]+1
        end
    end
    out[#out+1] = escape(text:sub(start))
    return table.concat(out)
end

-- Project source byte boundaries onto a display with combining acute accents.
local function boundaries(text)
    local byOffset, byLetter, offset = {}, {}, 1
    for c in A:Chars(text) do
        if c ~= acute then
            byLetter[#byLetter+1] = offset
            byOffset[offset] = #byLetter
        end
        offset = offset + #c
    end
    byLetter[#byLetter+1] = offset
    byOffset[offset] = #byLetter
    return byOffset, byLetter
end

local function accentedForm(source, stress)
    if stress == 0 then return source end
    local out, n = {}, 0
    for char in A:Chars(source) do
        if char ~= acute then
            n = n+1
            out[#out+1] = char
            if n == stress then out[#out+1] = acute end
        end
    end
    return table.concat(out)
end

function A:QuestNotes(reading)
    local compiled = self.questReadings[reading.id]
    local selected, french, tips = {}, {}, {}
    if not compiled then return selected, french, tips end
    for _, field in ipairs(fields) do
        local entry = compiled[field]
        local ru = reading.russian[field]
        local fr = reading.french[field]
        if entry and ru and signature(ru) == entry[1] then
            local sameFrench = fr and signature(fr) == entry[2]
            selected[field], french[field] = {}, {}
            for _, row in ipairs(entry[3]) do
                local source = ru:sub(row[1], row[2])
                if signature(source) == row[3] then
                    local note = {row[1],row[2],source,accentedForm(source,row[4]),row[5],row[6],row[7]}
                    selected[field][#selected[field]+1] = note
                    tips[#tips+1] = note
                    if sameFrench and row[8] and signature(fr:sub(row[8], row[9])) == row[10] then
                        note.fr = {row[8], row[9]}
                        french[field][#french[field]+1] = note.fr
                    end
                end
            end
        end
    end
    return selected, french, tips
end

local function adventureTokens(text)
    local tokens, parts = {}, {}
    local offset, start, inTemplate = 1, 1, false
    local sentenceStart, wasStart = true, true
    local function flush()
        if #parts == 0 then return end
        local word = table.concat(parts)
        local joined = text:sub(start-1,start-1) == "-" or text:sub(offset,offset) == "-"
        tokens[#tokens+1] = {
            word=word, key=A:Normalize(word), start=start, last=offset-1, firstInSentence=wasStart,
        }
        -- Sentence-initial capitals can be ordinary words. Mid-sentence
        -- capitals are skipped to avoid collecting known words inside names.
        local first = word:match("^[\194-\244][\128-\191]*")
        local letter = A.letterMap[first]
        tokens[#tokens].useful = not joined and (wasStart or not letter or first ~= letter[1])
        parts = {}
    end
    for char in A:Chars(text) do
        if not inTemplate and (A.letterMap[char] or (char == acute and #parts > 0)) then
            if #parts == 0 then start, wasStart = offset, sentenceStart end
            parts[#parts+1] = char
            sentenceStart = false
        else
            flush()
            if char == "{" then inTemplate = true
            elseif char == "}" then inTemplate = false end
            if char:match("^[.!?\n]$") or char == "…" then sentenceStart = true end
        end
        offset = offset + #char
    end
    flush()
    return tokens
end

local function adventureEntry(token, compiled, before, after, text, field)
    if not token.useful then return end
    local mapped = A.adventureForms[token.key]
    local context
    if token.key == "есть" and before and after
        and before.key == "что" and (after.key == "одна" or after.key == "один" or after.key == "одно")
        and text:sub(token.last+1,after.start-1):match("^%s+$")
        and text:sub(before.last+1,token.start-1):match("^%s+$") then
        mapped = {"есть:exist","есть","il y a"}
        context = token.word.." "..after.word.."…"
    elseif not mapped and compiled and token.key == "сердца"
        and A:Normalize(compiled[5]) == "сердце" and compiled[6] == "cœurs"
        and compiled[4]:find(acute,1,true) then
        mapped = {"сердце",compiled[4],"cœurs"}
    end
    if not mapped then return end
    if ambiguousCommands[token.key] and not (field == "objective" and token.firstInSentence) then
        return
    end
    local id, form, meaning = unpack(mapped)
    local initial = token.word:match("^[\194-\244][\128-\191]*")
    local first = form:match("^[\194-\244][\128-\191]*")
    local letter = A.letterMap[initial]
    if first and letter and initial == letter[1] then form = initial..form:sub(#first+1) end
    local isMatch = compiled and compiled[6] == meaning
    local row = {token.start,token.last,token.word,form,A.adventureWords[id].ru,meaning,
                 isMatch and compiled[7] or "",id,context}
    if isMatch then row.fr = compiled.fr end
    return row
end

function A:AdventureQuestNotes(reading)
    local compiled = self:QuestNotes(reading)
    local available, selected, french, tips, seen = {}, {}, {}, {}, {}
    local priority = {"title","objective","body"}
    for _, field in ipairs(priority) do
        local source = reading.russian[field]
        available[field], selected[field], french[field] = {}, {}, {}
        if source then
            local byStart = {}
            for _, note in ipairs(compiled[field] or {}) do byStart[note[1]] = note end
            local tokens = adventureTokens(source)
            for i, token in ipairs(tokens) do
                local row = adventureEntry(token, byStart[token.start], tokens[i-1],tokens[i+1],source,field)
                if row then available[field][#available[field]+1] = row end
            end
        end
    end

    local pronounShown
    local function choose(field)
        if #tips >= 2 then return end
        for _, row in ipairs(available[field]) do
            local isPronoun = self.adventureWords[row[8]].group == "pronoms"
            if not seen[row[8]] and not (pronounShown and isPronoun) then
                selected[field][#selected[field]+1] = row
                if row.fr then french[field][#french[field]+1] = row.fr end
                seen[row[8]] = true
                if isPronoun then pronounShown = true end
                tips[#tips+1] = row
                return
            end
        end
    end

    for _, field in ipairs(priority) do choose(field) end
    for _, field in ipairs(priority) do choose(field) end
    return selected, french, tips
end

function A:QuestRussianText(source, display, rows)
    if not rows or #rows == 0 then return escape(display) end
    if source:gsub(acute, "") ~= display:gsub(acute, "") then display = source end
    local offsets = boundaries(source)
    local _, positions = boundaries(display)
    local marks = {}
    for _, row in ipairs(rows) do
        local start = positions[offsets[row[1]]]
        local nextWord = positions[offsets[row[2]+1]]
        if start and nextWord then
            local form = display:sub(start,nextWord-1)
            if row[4]:find(acute, 1, true) and self:Normalize(row[4]) == self:Normalize(form) then
                form = self:RussianDisplay(row[4])
            end
            marks[#marks+1] = {start,nextWord-1,form}
        end
    end
    return ranges(display, marks)
end

function A:QuestFrenchText(source, spans)
    return ranges(source, spans or {})
end
