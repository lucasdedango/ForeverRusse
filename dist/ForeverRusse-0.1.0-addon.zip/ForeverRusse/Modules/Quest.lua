local _, A = ...
local accent = "22665b"
local function highlight(word)
    return "|cff"..accent..word.."|r"
end

local function questText(value)
    local text = A:Plain(value)
    if text and text ~= "" then return (text:gsub("\r\n", "\n")) end
end

local function questSections(record)
    return {
        title=questText(record.title),
        body=questText(record.description) or questText(record.details),
        objective=questText(record.summary) or questText(record.objectiveText),
    }
end

local function normalizedLine(text)
    return text and text:gsub(" "," "):gsub(" "," "):gsub("’","'"):gsub("%s+"," "):match("^%s*(.-)%s*$")
end

local function questDialogue(id, stage, native)
    local provider = A:Provider()
    if not provider or not native then return end
    local source = A:Safe("FRS:dialogue:fr", provider.GetQuestDialogue, provider, id, nil, "frFR")
    local target = A:Safe("FRS:dialogue:ru", provider.GetQuestDialogue, provider, id, nil, "ruRU")
    if type(source) ~= "table" or type(target) ~= "table" then return end
    local observed, keys = normalizedLine(native), {}
    for _, row in ipairs(source) do
        local text = normalizedLine(questText(row.text))
        if row.stage == stage and text == observed and type(row.key) == "string" then keys[row.key] = true end
    end
    local result
    for _, row in ipairs(target) do
        if row.stage == stage and keys[row.key] then
            local text = questText(row.text)
            -- Only use static translations with an exact source match.
            if not text or text:find("%$%a") or text:find("{[%w_]+}") or (result and result ~= text) then return end
            result = text
            keys[row.key] = nil
        end
    end
    if next(keys) == nil then return result end
end

function A:GetQuestReading(id, native, stage)
    local record, source, ai = self:Lookup("quest", id)
    if not record then return end
    local russian = questSections(record)
    if not next(russian) then return end
    local french = questSections(self:Lookup("quest", id, "frFR") or {})
    for field, value in pairs(native or {}) do french[field] = value end
    if stage and stage ~= "accept" then
        french.body = native and native.body
        russian.body = questDialogue(id, stage, french.body)
    end
    self:Observe(russian.title, french.title, "quête")
    return {id=id, russian=russian, french=french, source=source, ai=ai}
end

function A:GetGossipReading(options)
    local provider = self:Provider()
    if not provider or self:Combat() then return end
    if (issecretvalue and issecretvalue(options)) or type(options) ~= "table" then return end
    local translated = {}
    for _, option in ipairs(options) do
        if (not issecretvalue or not issecretvalue(option)) and type(option) == "table" then
            local id = self:ID(option.gossipOptionID)
            local ru = id and questText(self:Safe("FRS:gossip", provider.GetGossipOptionName, provider, id, "ruRU"))
            if ru then
                local ai = self:Safe("FRS:gossip:AI", provider.IsAITranslated, provider, "gossipoptions", id, "ruRU")
                translated[#translated+1] = {ru=ru, fr=self:Plain(option.name), ai=ai}
            end
        end
    end
    if #translated > 0 then return {options=translated} end
end

local function gossipReadingText(reading, compare)
    local blocks = {}
    for _, option in ipairs(reading.options) do
        local display, hints = A:ReadingFor(option.ru, option.fr, nil, true)
        local lines = {(display:gsub("|","||"))}
        if option.ai then lines[1] = lines[1].." [IA]" end
        for _, hint in ipairs(hints) do lines[#lines+1] = hint:gsub("|","||") end
        if compare and option.fr then lines[#lines+1] = option.fr:gsub("|","||") end
        blocks[#blocks+1] = table.concat(lines,"\n")
    end
    return table.concat(blocks,"\n\n").."\n\nFRS"
end

function A:QuestReadingText(reading, compare)
    if reading.options then return gossipReadingText(reading, compare) end
    local selected, french, tips = self:QuestNotes(reading)
    local order = {"title", "objective", "body"}
    local russian, aids = {}, {}
    for _, field in ipairs(order) do
        local text = reading.russian[field]
        if text then
            -- Long passages get vocabulary aids instead of a duplicate phonetic block.
            local display, hints = text, {}
            if #text <= 360 then
                display, hints = self:ReadingFor(text, reading.french[field], nil, true)
            elseif not self:On("hints") or not self:On("phoneticAccents") then
                display = self:RussianDisplay(text)
            end
            russian[field] = self:QuestRussianText(text, display, selected[field])
            aids[field] = hints
        end
    end
    local lines = {}
    local function append(field, russianLabel, frenchLabel)
        if russian[field] then
            local text = (russianLabel and russianLabel.."\n" or "")..russian[field]
            if #aids[field] > 0 then
                text = text.."\n"..table.concat(aids[field], "\n"):gsub("|","||")
            end
            lines[#lines+1] = text
        end
        if compare and reading.french[field] then
            lines[#lines+1] = frenchLabel.."\n"..self:QuestFrenchText(reading.french[field], french[field])
        end
    end
    append("title", nil, "Titre français")
    append("objective", "Цель", "Objectif en français")
    if #tips > 0 then
        local vocabulary = {"Mots à repérer"}
        for _, entry in ipairs(tips) do
            local display, hints = self:ReadingFor(entry[4], entry[6], nil, true)
            local tip = highlight(display).." — "..entry[6]
            if #hints > 0 then tip = tip.." · "..table.concat(hints, " · ") end
            local lemma = self:RussianDisplay(entry[5])
            local distinctLemma = self:Normalize(lemma) ~= self:Normalize(display)
            local grammar = entry[7] ~= "" and ("≈ "..entry[7]) or ""
            if distinctLemma then
                tip = tip.."\n"..lemma..(grammar ~= "" and (" · "..grammar) or "")
            elseif grammar ~= "" then
                tip = tip.."\n"..grammar
            end
            vocabulary[#vocabulary+1] = tip
        end
        lines[#lines+1] = table.concat(vocabulary, "\n")
    end
    append("body", nil, "Récit en français")
    if compare and not next(reading.french) then
        lines[#lines+1] = "Texte français indisponible."
    end
    local attribution = "Quête #"..reading.id.." · "..reading.source
    if reading.ai then attribution = attribution.." · traduction IA signalée" end
    lines[#lines+1] = attribution
    return table.concat(lines, "\n\n")
end

function A:HideQuestReading(onlyAttached)
    if self.questPanel and (not onlyAttached or self.questAnchor) then
        self.questPanel:Hide()
        self.questAnchor = nil
    end
end

local function questEvent(stage)
    if A:Combat() or not A:On("quests") or not A:On("questCompanion") then return end
    local id = A:ID(A:Safe("quest:id", GetQuestID))
    if not id then A:HideQuestReading(true); return end
    local function show()
        if A:Combat() or not A:On("quests") or not A:On("questCompanion")
            or not QuestFrame or not QuestFrame:IsVisible()
            or id ~= A:ID(A:Safe("quest:id", GetQuestID)) then return end
        local getBody = ({accept=GetQuestText, progress=GetProgressText, complete=GetRewardText})[stage]
        local native = {
            title=questText(A:Safe("quest:title", GetTitleText)),
            body=questText(A:Safe("quest:body", getBody)),
            objective=questText(A:Safe("quest:objective", GetObjectiveText)),
        }
        local reading = A:GetQuestReading(id, native, stage)
        if not reading then A:HideQuestReading(true); return end
        A:ShowQuestReading(reading, QuestFrame)
    end
    -- Blizzard shows the quest panel in response to the same event.
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function() A:Safe("quest:companion", show) end)
    else
        show()
    end
end

if A.eventFrame then
    for event, stage in pairs({QUEST_DETAIL="accept", QUEST_PROGRESS="progress", QUEST_COMPLETE="complete"}) do
        A:Event(event, function() questEvent(stage) end)
    end
    local function hideFor(frame)
        if frame and A.questAnchor == frame then A:HideQuestReading(true) end
    end
    A:Event("QUEST_FINISHED", function() hideFor(QuestFrame) end)
    A:Event("QUEST_GREETING", function() hideFor(QuestFrame) end)
    A:Event("GOSSIP_SHOW", function()
        if A:Combat() or not A:On("phoneticGossip") or not C_GossipInfo or not GossipFrame then return end
        local function show()
            if A:Combat() or not A:On("phoneticGossip") or not GossipFrame:IsVisible() then return end
            local options = A:Safe("gossip:options", C_GossipInfo.GetOptions)
            local reading = A:GetGossipReading(options)
            if reading then A:ShowQuestReading(reading, GossipFrame)
            else hideFor(GossipFrame) end
        end
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function() A:Safe("gossip:companion", show) end)
        else
            show()
        end
    end)
    A:Event("GOSSIP_CLOSED", function() hideFor(GossipFrame) end)
    A:Event("PLAYER_REGEN_DISABLED", function() A:HideQuestReading() end)
    A:Event("PLAYER_LOGIN", function()
        if QuestFrame then QuestFrame:HookScript("OnHide", function(frame) hideFor(frame) end) end
        if GossipFrame then GossipFrame:HookScript("OnHide", function(frame) hideFor(frame) end) end
    end)
end
