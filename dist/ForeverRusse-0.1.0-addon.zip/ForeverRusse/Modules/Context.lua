local _, A = ...
function A:SetContext(ru,fr,source,ai,force)
    if not self:Plain(ru) or ru=="" then return end
    self:Observe(ru,fr,source)
    if self.contextPinned and not force then return end
    if self.context and self.context.ru==ru and self.context.fr==(fr or "") and self.context.source==source then return end
    self.context={ru=ru,fr=self:Plain(fr) or "",source=source or "jeu",ai=ai}
    if self.RefreshContext then self:RefreshContext() end
end
function A:ContextGlossary()
    local out, seen={},{}
    if not self.context then return out end
    for _,w in ipairs(self:Words(self.context.ru)) do local r=self:Gloss(w); if r and not seen[r[1]] then seen[r[1]]=true; out[#out+1]={w,r[1],r[2]} end end
    return out
end
