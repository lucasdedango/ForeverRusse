local _, A = ...
local acute = "́"
local fields = {"title", "objective", "body"}

local function signature(text)
    local state = 0
    for i = 1, #text do
        state = (131 * state + text:byte(i)) % 2147483647
    end
    return tostring(#text)..":"..tostring(state)
end

local function escape(text)
    return (text:gsub("|", "||"))
end

local function ranges(text, spans)
    table.sort(spans, function(a,b) return a[1] < b[1] end)
    local start = 1
    local out = {}
    for _, span in ipairs(spans) do
        if span[1] >= start then
            out[#out+1] = escape(text:sub(start, span[1]-1))
            out[#out+1] = "|cff22665b"..escape(span[3] or text:sub(span[1], span[2])).."|r"
            start = span[2]+1
        end
    end
    out[#out+1] = escape(text:sub(start))
    return table.concat(out)
end

-- Project source byte boundaries onto a display with combining acute accents.
local function boundaries(text)
    local byOffset, byLetter, offset = {}, {}, 1
    for c in A:Chars(text) do
        if c ~= acute then
            byLetter[#byLetter+1] = offset
            byOffset[offset] = #byLetter
        end
        offset = offset + #c
    end
    byLetter[#byLetter+1] = offset
    byOffset[offset] = #byLetter
    return byOffset, byLetter
end

local function accentedForm(source, stress)
    if stress == 0 then return source end
    local out, n = {}, 0
    for char in A:Chars(source) do
        if char ~= acute then
            n = n+1
            out[#out+1] = char
            if n == stress then out[#out+1] = acute end
        end
    end
    return table.concat(out)
end

function A:QuestNotes(reading)
    local compiled = self.questReadings[reading.id]
    local selected, french, tips = {}, {}, {}
    if not compiled then return selected, french, tips end
    for _, field in ipairs(fields) do
        local entry = compiled[field]
        local ru = reading.russian[field]
        local fr = reading.french[field]
        if entry and ru and signature(ru) == entry[1] then
            local sameFrench = fr and signature(fr) == entry[2]
            selected[field], french[field] = {}, {}
            for _, row in ipairs(entry[3]) do
                local source = ru:sub(row[1], row[2])
                if signature(source) == row[3] then
                    local note = {row[1],row[2],source,accentedForm(source,row[4]),row[5],row[6],row[7]}
                    selected[field][#selected[field]+1] = note
                    tips[#tips+1] = note
                    if sameFrench and row[8] and signature(fr:sub(row[8], row[9])) == row[10] then
                        french[field][#french[field]+1] = {row[8], row[9]}
                    end
                end
            end
        end
    end
    return selected, french, tips
end

function A:QuestRussianText(source, display, rows)
    if not rows or #rows == 0 then return escape(display) end
    if source:gsub(acute, "") ~= display:gsub(acute, "") then display = source end
    local offsets = boundaries(source)
    local _, positions = boundaries(display)
    local marks = {}
    for _, row in ipairs(rows) do
        local start = positions[offsets[row[1]]]
        local nextWord = positions[offsets[row[2]+1]]
        if start and nextWord then
            local form = display:sub(start,nextWord-1)
            if row[4]:find(acute, 1, true) and self:Normalize(row[4]) == self:Normalize(form) then
                form = self:RussianDisplay(row[4])
            end
            marks[#marks+1] = {start,nextWord-1,form}
        end
    end
    return ranges(display, marks)
end

function A:QuestFrenchText(source, spans)
    return ranges(source, spans or {})
end
