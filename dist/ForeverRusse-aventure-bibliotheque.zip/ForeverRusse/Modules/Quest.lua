local _, A = ...
local accent = "22665b"
local function highlight(word)
    return "|cff"..accent..word.."|r"
end

local function questText(value)
    local text = A:Plain(value)
    if text and text ~= "" then return (text:gsub("\r\n", "\n")) end
end

local function questSections(record)
    return {
        title=questText(record.title),
        body=questText(record.description) or questText(record.details),
        objective=questText(record.summary) or questText(record.objectiveText),
    }
end

local function normalizedLine(text)
    return text and text:gsub(" "," "):gsub(" "," "):gsub("’","'"):gsub("%s+"," "):match("^%s*(.-)%s*$")
end

local function questDialogue(id, stage, native)
    local provider = A:Provider()
    if not provider or not native then return end
    local source = A:Safe("FRS:dialogue:fr", provider.GetQuestDialogue, provider, id, nil, "frFR")
    local target = A:Safe("FRS:dialogue:ru", provider.GetQuestDialogue, provider, id, nil, "ruRU")
    if type(source) ~= "table" or type(target) ~= "table" then return end
    local observed, keys = normalizedLine(native), {}
    for _, row in ipairs(source) do
        local text = normalizedLine(questText(row.text))
        if row.stage == stage and text == observed and type(row.key) == "string" then keys[row.key] = true end
    end
    local result
    for _, row in ipairs(target) do
        if row.stage == stage and keys[row.key] then
            local text = questText(row.text)
            -- Only use static translations with an exact source match.
            if not text or text:find("%$%a") or text:find("{[%w_]+}") or (result and result ~= text) then return end
            result = text
            keys[row.key] = nil
        end
    end
    if next(keys) == nil then return result end
end

function A:GetQuestReading(id, native, stage)
    local record, source, ai = self:Lookup("quest", id)
    if not record then return end
    local russian = questSections(record)
    if not next(russian) then return end
    local french = questSections(self:Lookup("quest", id, "frFR") or {})
    for field, value in pairs(native or {}) do french[field] = value end
    if stage and stage ~= "accept" then
        french.body = native and native.body
        russian.body = questDialogue(id, stage, french.body)
    end
    return {id=id, russian=russian, french=french, source=source, ai=ai}
end

function A:QuestVocabularyLine(entry, details)
    local word, cue = self:StudyReading(entry[4])
    local lines = {highlight(word).." — "..entry[6], cue}
    if details then
        local base = self:Normalize(entry[5]) ~= self:Normalize(word) and entry[5] or ""
        local grammar = entry[7] ~= "" and "≈ "..entry[7] or ""
        if base ~= "" or grammar ~= "" then
            lines[#lines+1] = base..(base ~= "" and grammar ~= "" and " · " or "")..grammar
        end
    end
    return table.concat(lines,"\n")
end

function A:QuestReadingSections(reading, compare)
    local selected, french, tips = self:AdventureQuestNotes(reading)
    local russian = {}
    for _, field in ipairs({"title", "objective", "body"}) do
        local source = reading.russian[field]
        if source then
            russian[field] = self:QuestRussianText(source, selected[field])
        end
    end
    local lines = {}
    local function append(field, russianLabel, frenchLabel)
        if russian[field] then
            local text = (russianLabel and russianLabel.."\n" or "")..russian[field]
            lines[#lines+1] = text
        end
        if compare and reading.french[field] then
            lines[#lines+1] = frenchLabel.."\n"..self:QuestFrenchText(reading.french[field], french[field])
        end
    end
    append("title", nil, "Titre français")
    append("objective", "Цель", "Objectif en français")
    local top = table.concat(lines,"\n\n")
    lines = {}
    append("body", nil, "Récit en français")
    if compare and not next(reading.french) then
        lines[#lines+1] = "Texte français indisponible."
    end
    local attribution = "Quête #"..reading.id.." · "..reading.source
    if reading.ai then attribution = attribution.." · traduction IA signalée" end
    lines[#lines+1] = attribution
    return top, tips, table.concat(lines, "\n\n")
end

function A:HideQuestReading(onlyAttached)
    if self.questPanel and (not onlyAttached or self.questAnchor) then
        self.questPanel:Hide()
        self.questAnchor = nil
    end
end

local function questEvent(stage)
    if A:Combat() or not A:On("quests") or not A:On("questCompanion") then return end
    local id = A:ID(A:Safe("quest:id", GetQuestID))
    if not id then A:HideQuestReading(true); return end
    local function show()
        if A:Combat() or not A:On("quests") or not A:On("questCompanion")
            or not QuestFrame or not QuestFrame:IsVisible()
            or id ~= A:ID(A:Safe("quest:id", GetQuestID)) then return end
        local getBody = ({accept=GetQuestText, progress=GetProgressText, complete=GetRewardText})[stage]
        local native = {
            title=questText(A:Safe("quest:title", GetTitleText)),
            body=questText(A:Safe("quest:body", getBody)),
            objective=questText(A:Safe("quest:objective", GetObjectiveText)),
        }
        local reading = A:GetQuestReading(id, native, stage)
        if not reading then A:HideQuestReading(true); return end
        A:ShowQuestReading(reading, QuestFrame)
    end
    -- Blizzard shows the quest panel in response to the same event.
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function() A:Safe("quest:companion", show) end)
    else
        show()
    end
end

if A.eventFrame then
    for event, stage in pairs({QUEST_DETAIL="accept", QUEST_PROGRESS="progress", QUEST_COMPLETE="complete"}) do
        A:Event(event, function() questEvent(stage) end)
    end
    local function hideFor(frame)
        if frame and A.questAnchor == frame then A:HideQuestReading(true) end
    end
    A:Event("QUEST_FINISHED", function() hideFor(QuestFrame) end)
    A:Event("QUEST_GREETING", function() hideFor(QuestFrame) end)
    A:Event("PLAYER_REGEN_DISABLED", function() A:HideQuestReading() end)
    A:Event("PLAYER_LOGIN", function()
        if QuestFrame then QuestFrame:HookScript("OnHide", function(frame) hideFor(frame) end) end
    end)
end
