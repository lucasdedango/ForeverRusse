local _, A = ...
local function label(parent, x,y,w,text,template)
    local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlight")
    A:ApplyFont(f)
    f:SetPoint("TOPLEFT",x,y); f:SetWidth(w); f:SetJustifyH("LEFT"); f:SetJustifyV("TOP"); f:SetText(text or ""); return f
end
local function button(parent,x,y,w,h,text,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate"); b:SetSize(w,h); b:SetPoint("TOPLEFT",x,y); A:ApplyButtonFonts(b); b:SetText(text); b:SetScript("OnClick",fn); return b
end
local function scroll(parent,x,y,w,h)
    local s=CreateFrame("ScrollFrame",nil,parent,"UIPanelScrollFrameTemplate"); s:SetPoint("TOPLEFT",x,y); s:SetSize(w,h)
    local child=CreateFrame("Frame",nil,s); child:SetSize(w-8,h); s:SetScrollChild(child); return s,child
end
local function start(A, kind, introduce)
    local active, starters = A:StartAdventure(kind, introduce)
    A.adventureIntro = starters and {kind=kind,words=starters} or nil
    A:RefreshAdventure()
    return active
end

local function refreshQuestion(quiz, q, answer, heading, nextLabel)
    quiz.number:SetText(heading)
    local reading, pronunciation = q.prompt, ""
    if not q.reverse and q.kind ~= "letter" then
        reading, pronunciation = A:StudyReading(q.prompt)
    end
    quiz.prompt:SetText(reading)
    quiz.pronunciation:SetText(pronunciation)
    quiz.listen.word = q.kind == "letter" and q.id or q.ru
    quiz.listen:SetEnabled(A:On("audio"))
    quiz.listen:SetShown(not q.reverse or answer ~= nil)
    for i,b in ipairs(quiz.answers) do
        b.choice = q.choices[i]
        b:SetShown(b.choice ~= nil)
        b:SetEnabled(answer == nil)
        local color
        if answer and b.choice == q.correct then color = "|cff8fdf9f"
        elseif answer and b.choice == answer then color = "|cffffa29b" end
        b:SetText((color or "")..(b.choice or "")..(color and "|r" or ""))
    end
    local feedback = ""
    if answer then
        if answer == q.correct then feedback = "|cff8fdf9fCorrect !|r"
        else feedback = "Réponse : "..q.correct end
        if q.reverse then
            local word, cue = A:StudyReading(q.ru)
            feedback = feedback.."\n"..word.."  "..cue
        end
    end
    quiz.feedback:SetText(feedback)
    quiz.next:SetShown(answer ~= nil)
    quiz.next:SetText(nextLabel)
end

local function questionCategory(question)
    if question.reverse then return "Quel mot russe ?" end
    if question.kind == "letter" then return "Comment se lit cette lettre ?" end
    return "Quel est le sens ?"
end

function A:RefreshAdventureNotice()
    if not self.db then return end
    local state = self:AdventureState()
    local show = ((state.tickets or 0)>0 or state.active ~= nil)
        and not self:Combat() and not (self.frame and self.frame:IsShown())
    if not self.adventureNotice and show then
        local notice = CreateFrame("Button",nil,UIParent,"UIPanelButtonTemplate")
        notice:SetSize(140,28)
        notice:SetPoint("TOPRIGHT",-32,-228)
        A:ApplyButtonFonts(notice)
        notice:SetScript("OnClick",function() A:ShowTab("adventure") end)
        self.adventureNotice = notice
    end
    if self.adventureNotice then
        self.adventureNotice:SetText(state.active and "Reprendre" or "Défi de quête")
        self.adventureNotice:SetShown(show)
    end
end

local function refreshOnReset(A, state)
    if A.adventureTimer then A.adventureTimer:Cancel(); A.adventureTimer=nil end
    if not C_Timer or not C_Timer.NewTimer then return end
    local now = A:Now()
    local nextChange
    for _, key in ipairs({"dailyUntil","bonusUntil","bonusOffer"}) do
        local expiry = state[key]
        if expiry and expiry > now and (not nextChange or expiry < nextChange) then nextChange=expiry end
    end
    if nextChange then
        A.adventureTimer = C_Timer.NewTimer(nextChange-now+1,function()
            A.adventureTimer=nil
            A:RefreshAdventure()
        end)
    end
end

function A:RefreshAdventure()
    if not self.frame or self.tab ~= "adventure" or not self.frame:IsShown() then return end
    local state = self:AdventureState()
    local ui = self.adventureUI
    local level,xp,cap,words,mastered = self:AdventureProgress()
    ui.level:SetText(("Niveau %d"):format(level))
    ui.xp:SetMinMaxValues(0,cap)
    ui.xp:SetValue(xp)
    ui.xpText:SetText(("%d / %d XP"):format(xp,cap))
    ui.words:SetText(("%d / %d mots rencontrés · %d acquis"):format(words,#self.adventurePool,mastered))

    local active, intro = state.active, self.adventureIntro
    ui.home:SetShown(not active and not intro)
    ui.quiz:SetShown(active ~= nil)
    ui.intro:SetShown(intro ~= nil and not active)
    if active then
        local q = active.questions[active.index]
        refreshQuestion(ui.challenge,q,active.answer,("%d / %d   %s"):format(active.index,#active.questions,questionCategory(q)),
            active.index == #active.questions and "Terminer" or "Suivant")
    elseif intro then
        local lines = {}
        for _, word in ipairs(intro.words) do
            local reading, cue = self:StudyReading(word.ru)
            lines[#lines+1] = reading.." — "..word.fr.."\n"..cue
        end
        ui.introWords:SetText(table.concat(lines,"\n"))
    else
        local quest,daily,bonus = self:AdventureAvailability()
        ui.quest:SetEnabled(not not quest)
        ui.quest:SetText(quest and ("Défi de quête (%d)"):format(state.tickets) or "Défi de quête")
        ui.daily:SetEnabled(not not daily)
        ui.daily:SetText(daily and "Défi quotidien" or "Quotidien indisponible")
        ui.bonus:SetShown(not not bonus)
        local summary = state.summary
        if summary then
            ui.summary:SetText(("%d / %d bonnes réponses · +%d XP"):format(summary.score,summary.total,summary.reward))
        elseif not quest then
            ui.summary:SetText("Rends une quête pour débloquer un défi.")
        else
            ui.summary:SetText("3 mots · 2 lettres")
        end
    end
    self:RefreshAdventureNotice()
    refreshOnReset(self,state)
end

local function page(parent, top)
    local p = CreateFrame("Frame",nil,parent)
    p:SetPoint("TOPLEFT",24,top or -147)
    p:SetSize(442,282)
    return p
end

local function makeQuiz(parent, y, onAnswer, onNext)
    local quiz = {answers={}}
    quiz.number = label(parent,0,y,442,"")
    quiz.prompt = label(parent,0,y-24,330,"","GameFontNormalLarge")
    quiz.pronunciation = label(parent,0,y-48,442,"")
    quiz.pronunciation:SetTextColor(.85,.85,.85)
    quiz.listen = button(parent,342,y-24,100,25,"Écouter",function(b) A:Speak(b.word) end)
    for i=1,4 do
        quiz.answers[i] = button(parent,0,y-77-(i-1)*32,442,29,"",function(b) onAnswer(b.choice) end)
    end
    quiz.feedback = label(parent,0,y-213,442,"")
    quiz.next = button(parent,292,y-253,150,29,"Suivant",onNext)
    return quiz
end

local displaySettings = {
    {"Infobulles d’objets", "tooltips"},
    {"Infobulles de sorts", "spells"},
    {"Infobulles de PNJ", "units"},
    {"Parchemin de quête automatique", "questCompanion"},
    {"Russe sous le titre", "tooltipBelowTitle"},
    {"Coloration des lettres", "colorLetters"},
    {"Prononciation dans les infobulles", "hints"},
    {"Translittération latine", "phoneticLatin"},
    {"Synthèse vocale", "audio"},
}

local function showSettings(A)
    if not A.displaySettings then
        local pane = page(A.frame)
        pane:SetPoint("TOPLEFT",24,-62)
        local checks = {}
        for i, setting in ipairs(displaySettings) do
            local title, key = unpack(setting)
            local y = -(i-1)*35
            local check = CreateFrame("CheckButton",nil,pane,"UICheckButtonTemplate")
            check:SetPoint("TOPLEFT",0,y)
            label(pane,31,y-9,403,title)
            check:SetScript("OnClick",function(b)
                local enabled = not not b:GetChecked()
                A.db.settings[key] = enabled
                if key == "questCompanion" then A.db.settings.quests = enabled end
            end)
            checks[key] = check
        end
        A.displaySettings = {pane=pane,checks=checks}
    end
    for key, check in pairs(A.displaySettings.checks) do
        check:SetChecked(A:On(key) and (key ~= "questCompanion" or A:On("quests")))
    end
    A.displaySettings.pane:Show()
end

local function refreshAlphabet()
    local ui = A.alphabetUI
    local letter, example = A.alphabet[ui.index], A.alphabetExamples[ui.index]
    local reading, cue = A:StudyReading(example)
    ui.title:SetText(letter[1].." "..letter[2])
    ui.description:SetText(letter[4])
    ui.example:SetText(reading.."  "..cue)
    ui.listen.word = example
    ui.listen:SetEnabled(A:On("audio"))
    for i, key in ipairs(ui.keys) do
        local row = A.alphabet[i]
        key:SetText(A:Color(row[1].." "..row[2]))
        if i == ui.index then key:LockHighlight() else key:UnlockHighlight() end
    end
end

local function buildAlphabet(parent)
    local pane = page(parent,-103)
    local ui = {pane=pane,keys={},index=1}
    for i=1,#A.alphabet do
        ui.keys[i] = button(pane,((i-1)%11)*40,-math.floor((i-1)/11)*37,38,34,"",function()
            ui.index = i
            refreshAlphabet()
        end)
    end
    ui.title = label(pane,0,-128,442,"","GameFontNormalLarge")
    ui.description = label(pane,0,-161,442,"")
    ui.example = label(pane,0,-210,320,"")
    ui.listen = button(pane,326,-202,116,26,"Écouter le mot",function(b) A:Speak(b.word) end)
    return ui
end

local practiceModes = {{"Lettres","letter"},{"Russe → FR","ru-fr"},{"Français → RU","fr-ru"},{"Phrases","phrase"}}

local function buildPractice(parent)
    local pane = page(parent,-103)
    local ui = {pane=pane, mode="letter", modes={}}
    label(pane,0,0,442,"Entraînement libre, sans XP.")
    local function refresh()
        local q = ui.question
        if q then refreshQuestion(ui.quiz,q,ui.answer,questionCategory(q),"Question suivante") end
    end
    local function newQuestion(mode)
        local previous = ui.mode == mode and ui.question and ui.question.id
        ui.question = A:PracticeQuestion(mode,previous)
        ui.mode, ui.answer = mode, nil
        for key, choice in pairs(ui.modes) do
            if key == mode then choice:LockHighlight() else choice:UnlockHighlight() end
        end
        refresh()
    end
    for i, entry in ipairs(practiceModes) do
        local text, mode = unpack(entry)
        ui.modes[mode] = button(pane,(i-1)*111,-27,106,26,text,function() newQuestion(mode) end)
    end
    ui.quiz = makeQuiz(pane,-68,function(choice)
        if ui.answer or A:Combat() then return end
        ui.answer = choice
        refresh()
    end,function() newQuestion(ui.mode) end)
    newQuestion(ui.mode)
    return ui
end

local libraryPageSize = 5
local frenchFold = {
    ["à"]="a",["â"]="a",["ä"]="a",["À"]="a",["Â"]="a",["Ä"]="a",
    ["ç"]="c",["Ç"]="c",["é"]="e",["è"]="e",["ê"]="e",["ë"]="e",
    ["É"]="e",["È"]="e",["Ê"]="e",["Ë"]="e",["î"]="i",["ï"]="i",["Î"]="i",["Ï"]="i",
    ["ô"]="o",["ö"]="o",["Ô"]="o",["Ö"]="o",["œ"]="oe",["Œ"]="oe",
    ["ù"]="u",["û"]="u",["ü"]="u",["Ù"]="u",["Û"]="u",["Ü"]="u",
}

local function libraryKey(text)
    return A:Normalize(text):gsub("[\194-\244][\128-\191]*",frenchFold)
end

local function refreshLibrary()
    local ui = A.libraryUI
    local query, matches = libraryKey(ui.search:GetText() or ""), {}
    local learned = A:AdventureState().words
    for _, word in ipairs(A.adventurePool) do
        local card = learned[word.id]
        if card and (libraryKey(card.ru.." "..word.ru):find(query,1,true)
                or libraryKey(card.fr.." "..word.fr):find(query,1,true)) then
            matches[#matches+1] = {word=word,card=card}
        end
    end
    table.sort(matches,function(left,right) return libraryKey(left.card.fr) < libraryKey(right.card.fr) end)
    local pages = math.max(1,math.ceil(#matches/libraryPageSize))
    ui.page = math.max(1,math.min(pages,ui.page))
    ui.status:SetText(#matches == 0 and (next(learned) and "Aucun résultat." or "Ton carnet se remplit avec les mots du parchemin.")
        or ("%d mot%s · %d / %d"):format(#matches,#matches == 1 and "" or "s",ui.page,pages))
    ui.previous:SetEnabled(ui.page > 1)
    ui.next:SetEnabled(ui.page < pages)
    local selected
    for i, row in ipairs(ui.rows) do
        local entry = matches[(ui.page-1)*libraryPageSize+i]
        row:SetShown(entry ~= nil)
        if entry then
            row.id = entry.word.id
            local reading, cue = A:StudyReading(entry.card.ru)
            row.title:SetText(reading.." — "..entry.card.fr)
            row.cue:SetText(cue)
            if ui.selected == row.id then selected = entry end
        end
    end
    if not selected then selected = matches[(ui.page-1)*libraryPageSize+1] end
    ui.selected = selected and selected.word.id
    for _, row in ipairs(ui.rows) do
        if row:IsShown() and row.id == ui.selected then row:LockHighlight() else row:UnlockHighlight() end
    end
    local text = ""
    if selected then
        local card, word = selected.card, selected.word
        if A:Normalize(card.ru) ~= A:Normalize(word.ru) then
            local reading, cue = A:StudyReading(word.ru)
            text = "Forme de base · "..reading.." — "..word.fr.."\n"..cue
        end
        if card.context and card.context ~= "" then
            text = (text ~= "" and text.."\n" or "").."Dans la quête · "..card.context
        end
        ui.listen.word = card.ru
    end
    ui.detail:SetText(text)
    ui.listen:SetShown(selected ~= nil)
    ui.listen:SetEnabled(A:On("audio"))
end

local function buildLibrary(parent)
    local pane = page(parent,-103)
    local ui = {pane=pane,page=1,rows={}}
    label(pane,0,-6,85,"Rechercher")
    local search = CreateFrame("EditBox",nil,pane,"InputBoxTemplate")
    search:SetSize(350,25)
    search:SetPoint("TOPLEFT",91,0)
    search:SetAutoFocus(false)
    search:SetMaxLetters(60)
    A:ApplyFont(search)
    search:SetScript("OnEscapePressed",function(box) box:ClearFocus() end)
    search:SetScript("OnEnterPressed",function(box) box:ClearFocus() end)
    search:SetScript("OnTextChanged",function()
        ui.page,ui.selected = 1,nil
        refreshLibrary()
    end)
    ui.search = search
    ui.status = label(pane,0,-37,442,"")
    for i=1,libraryPageSize do
        local row = button(pane,0,-59-(i-1)*37,442,35,"",function(b)
            ui.selected = b.id
            refreshLibrary()
        end)
        row.title = label(row,12,-3,420,"")
        row.cue = label(row,12,-17,420,"")
        row.cue:SetTextColor(.82,.82,.82)
        ui.rows[i] = row
    end
    ui.detail = label(pane,0,-251,315,"")
    ui.listen = button(pane,332,-250,110,27,"Écouter",function(b) A:Speak(b.word) end)
    ui.previous = button(pane,0,-314,130,26,"Précédent",function()
        ui.page = ui.page-1
        refreshLibrary()
    end)
    ui.next = button(pane,312,-314,130,26,"Suivant",function()
        ui.page = ui.page+1
        refreshLibrary()
    end)
    return ui
end

local studyTabs = {{"Aventure","adventure"},{"Alphabet","alphabet"},{"Entraînement","practice"},{"Bibliothèque","library"}}

function A:BuildUI()
    if self.frame then return end
    local f = CreateFrame("Frame","ForeverRussePanel",UIParent,"BackdropTemplate")
    f:Hide()
    f:SetSize(490,462)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving)
    f:SetScript("OnDragStop",f.StopMovingOrSizing)
    f:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true,tileSize=32,edgeSize=24,
        insets={left=5,right=5,top=5,bottom=5},
    })
    f:SetBackdropColor(.06,.08,.12,.97)
    f:SetScript("OnHide",function()
        if A.adventureTimer then A.adventureTimer:Cancel(); A.adventureTimer=nil end
        A:RefreshAdventureNotice()
    end)
    self.frame = f
    if UISpecialFrames then table.insert(UISpecialFrames,"ForeverRussePanel") end
    local close = CreateFrame("Button",nil,f,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",-3,-3)
    self.adventureHeading = label(f,24,-18,285,"Aventure","GameFontNormalLarge")
    self.displayButton = button(f,337,-13,110,26,"Affichage",function()
        A:ShowTab(A.tab == "display" and "adventure" or "display")
    end)
    self.studyTabs = {}
    for i, entry in ipairs(studyTabs) do
        local text, tab = unpack(entry)
        self.studyTabs[tab] = button(f,24+(i-1)*111,-48,106,28,text,function() A:ShowTab(tab) end)
    end

    local root = CreateFrame("Frame",nil,f)
    root:SetAllPoints(f)
    local ui = {root=root}
    self.adventureUI = ui
    ui.level = label(root,24,-89,100,"")
    ui.words = label(root,24,-116,430,"")
    ui.xp = CreateFrame("StatusBar",nil,root)
    ui.xp:SetPoint("TOPLEFT",115,-87)
    ui.xp:SetSize(350,19)
    ui.xp:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    ui.xp:SetStatusBarColor(.52,.37,.86)
    local background = ui.xp:CreateTexture(nil,"BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(.17,.16,.22,.95)
    ui.xpText = label(ui.xp,0,-3,350,"")
    ui.xpText:SetJustifyH("CENTER")

    ui.home = page(root)
    ui.summary = label(ui.home,0,-10,442,"","GameFontNormalLarge")
    ui.quest = button(ui.home,0,-58,210,33,"Défi de quête",function() start(A,"quest") end)
    ui.daily = button(ui.home,223,-58,219,33,"Défi quotidien",function() start(A,"daily") end)
    ui.bonus = button(ui.home,0,-103,210,30,"Exercice bonus",function() start(A,"bonus") end)

    ui.quiz = page(root)
    ui.challenge = makeQuiz(ui.quiz,0,function(choice)
            A:AnswerAdventure(choice)
            A:RefreshAdventure()
        end,function()
        A:AdvanceAdventure()
        A:RefreshAdventure()
    end)

    ui.intro = page(root)
    label(ui.intro,0,0,442,"Premiers mots","GameFontNormalLarge")
    ui.introWords = label(ui.intro,0,-42,442,"")
    ui.introWords:SetSpacing(8)
    button(ui.intro,0,-205,140,30,"Retour",function()
        A.adventureIntro = nil
        A:RefreshAdventure()
    end)
    ui.begin = button(ui.intro,292,-205,150,30,"Commencer",function()
        start(A,A.adventureIntro.kind,true)
    end)
end

function A:ShowTab(tab)
    if self:Combat() then return end
    if not self.frame then self:BuildUI() end
    local diagnostic = tab == "fonttest" or tab == "phoneticExport"
    local settings = tab == "display"
    self.tab = (diagnostic or settings or self.studyTabs[tab]) and tab or "adventure"
    self.adventureHeading:SetText(tab == "fonttest" and "Test de police"
        or tab == "phoneticExport" and "Formes manquantes" or settings and "Affichage" or "ForeverRusse")
    self.displayButton:SetShown(not diagnostic)
    self.displayButton:SetText(settings and "Aventure" or "Affichage")
    self.adventureUI.root:SetShown(self.tab == "adventure")
    for name, control in pairs(self.studyTabs) do
        control:SetShown(not (diagnostic or settings))
        if self.tab == name then control:LockHighlight() else control:UnlockHighlight() end
    end
    if self.tab == "alphabet" then self.alphabetUI = self.alphabetUI or buildAlphabet(self.frame) end
    if self.tab == "practice" then self.practiceUI = self.practiceUI or buildPractice(self.frame) end
    if self.tab == "library" then self.libraryUI = self.libraryUI or buildLibrary(self.frame) end
    if self.alphabetUI then self.alphabetUI.pane:SetShown(self.tab == "alphabet") end
    if self.practiceUI then self.practiceUI.pane:SetShown(self.tab == "practice") end
    if self.libraryUI then self.libraryUI.pane:SetShown(self.tab == "library") end
    if settings then showSettings(self)
    elseif self.displaySettings then self.displaySettings.pane:Hide() end
    if diagnostic then
        if not self.adventureDiagnostic then
            local pane = page(self.frame)
            pane:SetPoint("TOPLEFT",24,-58)
            local diagnostic, child = scroll(pane,0,0,438,306)
            local edit=CreateFrame("EditBox",nil,child)
            edit:SetPoint("TOPLEFT"); edit:SetWidth(402); edit:SetMultiLine(true)
            edit:SetFontObject(GameFontHighlight); self:ApplyFont(edit); edit:SetAutoFocus(false)
            edit:SetScript("OnEscapePressed",function(box) box:ClearFocus() end)
            edit:SetScript("OnEditFocusGained",function(box) box:HighlightText() end)
            button(pane,0,-315,120,28,"Aventure",function() A:ShowTab("adventure") end)
            self.adventureDiagnostic = {pane=pane,scroll=diagnostic,child=child,edit=edit}
        end
        local diag = self.adventureDiagnostic
        local text = self.tab == "fonttest" and self:FontSamples() or table.concat(self:MissingPronunciations(),"\n")
        local _, lines = text:gsub("\n", "")
        diag.edit:SetText(text)
        diag.edit:SetHeight(math.max(294,(lines+1)*36))
        diag.child:SetHeight(diag.edit:GetHeight()+4)
        diag.scroll:SetVerticalScroll(0)
        diag.pane:Show()
    elseif self.adventureDiagnostic then
        self.adventureDiagnostic.pane:Hide()
    end
    self.frame:Show()
    if self.tab == "alphabet" then refreshAlphabet() end
    if self.tab == "library" then refreshLibrary() end
    self:RefreshAdventure()
    self:RefreshAdventureNotice()
end

local function renderQuest(panel)
    local top,tips,bottom = A:QuestReadingSections(panel.reading, panel.compare)
    panel.top:SetText(top)
    local y = top ~= "" and panel.top:GetStringHeight()+15 or 0
    panel.vocabulary:SetShown(#tips > 0)
    if #tips > 0 then
        panel.vocabulary:SetPoint("TOPLEFT",0,-y)
        y = y+panel.vocabulary:GetStringHeight()+7
    end
    for i, row in ipairs(panel.words) do
        local tip = tips[i]
        row.text:SetShown(tip ~= nil)
        row.listen:SetShown(tip ~= nil)
        row.listen.word = tip and tip[4]
        row.listen:SetEnabled(A:On("audio"))
        if tip then
            row.text:SetText(A:QuestVocabularyLine(tip,panel.details))
            row.text:SetPoint("TOPLEFT",0,-y)
            row.listen:SetPoint("TOPLEFT",panel.wordButtonX,-y)
            y = y+math.max(25,row.text:GetStringHeight())+7
            A:RecordAdventureWord(tip[8],tip[4],tip[6],tip[9])
        end
    end
    panel.bottom:SetText(bottom)
    panel.bottom:SetPoint("TOPLEFT",0,-y)
    panel.body:SetHeight(math.max(panel.scroll:GetHeight(),y+panel.bottom:GetStringHeight()+12))
    A:RefreshAdventure()
    if A.tab == "library" then refreshLibrary() end
    panel.scroll:SetVerticalScroll(0)
    panel.compareButton:SetText(panel.compare and "Masquer le français" or "Comparer en français")
    panel.detailsButton:SetShown(#tips > 0)
    panel.detailsButton:SetText(panel.details and "Masquer les détails" or "Détails")
end

local function questLabel(parent, text, template)
    local row = label(parent,0,0,305,text,template)
    row:SetSpacing(4)
    row:SetTextColor(.25,.13,.06)
    return row
end

function A:ShowQuestReading(reading, anchor)
    if self:Combat() then return end
    local panel = self.questPanel
    if not panel then
        panel = CreateFrame("Frame", "ForeverRusseQuestPanel", UIParent, "BackdropTemplate")
        panel:Hide()
        panel:SetFrameStrata("DIALOG")
        panel:SetClampedToScreen(true)
        panel:EnableMouse(true)
        panel:SetBackdrop({
            bgFile="Interface\\Buttons\\WHITE8X8",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
            edgeSize=22, insets={left=5,right=5,top=5,bottom=5},
        })
        panel:SetBackdropColor(.95,.85,.66,1)
        panel:SetBackdropBorderColor(.61,.43,.23,1)
        panel.heading = label(panel,19,-16,250,"Quête en russe","GameFontNormalLarge")
        panel.heading:SetTextColor(.25,.13,.06)
        local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT",-4,-4)
        panel.compareButton = button(panel,18,-45,157,25,"Comparer en français",function()
            panel.compare = not panel.compare
            renderQuest(panel)
        end)
        panel.detailsButton = button(panel,183,-45,118,25,"Détails",function()
            panel.details = not panel.details
            renderQuest(panel)
        end)
        panel.scroll,panel.body = scroll(panel,19,-83,315,370)
        panel.top = questLabel(panel.body,"")
        panel.vocabulary = questLabel(panel.body,"Mots à repérer","GameFontHighlight")
        panel.bottom = questLabel(panel.body,"")
        panel.words = {}
        for i=1,2 do
            panel.words[i] = {
                text=questLabel(panel.body,""),
                listen=button(panel.body,0,0,72,24,"Écouter",function(b) A:Speak(b.word) end),
            }
        end
        if UISpecialFrames then table.insert(UISpecialFrames,"ForeverRusseQuestPanel") end
        self.questPanel = panel
    end
    panel.reading = reading
    panel.compare, panel.details = false, false
    self.questAnchor = anchor
    local width = math.min(380, math.max(320, UIParent:GetWidth() * .46))
    local height = math.min(550, UIParent:GetHeight() - 48)
    panel:SetSize(width,height)
    panel.scroll:SetSize(width-51,height-104)
    panel.body:SetWidth(width-51)
    panel.top:SetWidth(width-53)
    panel.bottom:SetWidth(width-53)
    panel.vocabulary:SetWidth(width-53)
    panel.wordButtonX = width-125
    for _, row in ipairs(panel.words) do row.text:SetWidth(panel.wordButtonX-7) end
    panel:ClearAllPoints()
    if anchor then
        local anchorRight = anchor:GetRight()
        local anchorLeft = anchor:GetLeft()
        if anchorRight and UIParent:GetWidth() - anchorRight >= width + 8 then
            panel:SetPoint("TOPLEFT",anchor,"TOPRIGHT",8,0)
        elseif anchorLeft and anchorLeft >= width + 8 then
            panel:SetPoint("TOPRIGHT",anchor,"TOPLEFT",-8,0)
        else
            panel:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-8,-24)
        end
    else
        panel:SetPoint("CENTER")
    end
    panel:Show()
    renderQuest(panel)
end
