local _, A = ...
local DAY=86400
function A:Card(ru,fr,category,source)
    ru,fr=self:Plain(ru),self:Plain(fr)
    if not ru or not fr or fr:match("^%s*$") or #ru>360 or #fr>360 or not ru:find("[\208\209]") then return end
    local key=self:Normalize(ru).."\031"..fr
    local c=self.db.cards[key]
    if not c then
        local n=0; for _ in pairs(self.db.cards) do n=n+1 end
        if n>=5000 then return end
        c={ru=ru,fr=fr,category=category or "jeu",source=source or "manuel",seen=0,due=0,streak=0}; self.db.cards[key]=c
    end
    return c
end
function A:Grade(c,good,now)
    now=now or self:Now(); c.reviews=(c.reviews or 0)+1
    if good then c.streak=(c.streak or 0)+1; c.due=now+({DAY,3*DAY,7*DAY,14*DAY,30*DAY})[math.min(c.streak,5)]
    else c.streak=0; c.due=now+300; c.errors=(c.errors or 0)+1 end
    c.lastReview=now
    local stats=self.db.stats; local day=math.floor(now/DAY)
    if stats.day~=day then stats.day=day; stats.today=0 end
    stats.today=(stats.today or 0)+1; stats.total=(stats.total or 0)+1
end
function A:LetterCard(letter, practice)
    local card = practice and {} or self.db.letters[letter[1]]
    if not card then
        card = {streak=0,due=0}
        self.db.letters[letter[1]] = card
    end
    card.ru = letter[1].." "..letter[2]
    card.fr = letter[1] == "Ъ" and "signe dur" or letter[1] == "Ь" and "signe mou" or letter[3]
    card.note = letter[4]
    return card
end
function A:Choices(c,pool,reverse)
    local key=reverse and "ru" or "fr"; local options={c[key]}; local used={[c[key]]=true}; local candidates={}
    for _,other in ipairs(pool) do if other[key] and not used[other[key]] then used[other[key]]=true; candidates[#candidates+1]=other[key] end end
    while #options<4 and #candidates>0 do options[#options+1]=table.remove(candidates,math.random(#candidates)) end
    for i=#options,2,-1 do local j=math.random(i); options[i],options[j]=options[j],options[i] end
    return options,c[key]
end
