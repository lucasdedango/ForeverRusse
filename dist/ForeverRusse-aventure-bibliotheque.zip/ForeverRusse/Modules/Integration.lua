local _, A = ...
function A:ListVoices()
    local voices=self:Voices(); if #voices==0 then self:Print("Aucune voix TTS exposée au client.") end
    for _,v in ipairs(voices) do self:Print(tostring(v.voiceID).." : "..tostring(v.name or v.voiceName or "?")) end
end
function A:Debug()
    local p=self:Provider(); self:Print("v"..self.version.." / FRS API "..(p and tostring(p.apiVersion) or "absente/incompatible"))
    if GetBuildInfo then local v,b,_,i=GetBuildInfo(); self:Print(tostring(v).." / "..tostring(b).." / TOC "..tostring(i)) end
    if GetLocale then self:Print("Locale : "..GetLocale()) end
    local n=0; for _ in pairs(self.db.missing) do n=n+1 end; self:Print("Identifiants sans traduction : "..n)
    self:Print("Formes phonétiques manquantes : "..#self:MissingPronunciations().." · /fru phonetic export")
    for k,v in pairs(self.errors) do self:Print(k.." : "..v) end
end
local function npcID(guid)
    guid=A:Plain(guid); if not guid then return end
    local kind,_,_,_,_,id=guid:match("^(%a+)%-([^-]+)%-([^-]+)%-([^-]+)%-([^-]+)%-([^-]+)%-")
    if kind=="Creature" or kind=="Vehicle" then return A:ID(tonumber(id)) end
end
local tooltipFrames = setmetatable({}, {__mode="k"})
local pendingComparison = setmetatable({}, {__mode="k"})
local tooltipSettings = {item="tooltips", spell="spells", npc="units"}

local function isComparison(tip)
    return tip == ShoppingTooltip1 or tip == ShoppingTooltip2
end

local function comparisonTooltip(manager, primary)
    local tips = manager.tooltip and manager.tooltip.shoppingTooltips
    if tips then return tips[primary and 1 or 2] end
end

local function translationBlock(tip)
    local frame = tooltipFrames[tip]
    if not frame then
        frame = CreateFrame("Frame", nil, tip)
        frame:Hide()
        frame.text = frame:CreateFontString(nil, "OVERLAY", "GameTooltipText")
        A:ApplyFont(frame.text)
        frame.text:SetPoint("TOPLEFT")
        frame.text:SetJustifyH("LEFT")
        frame.text:SetWordWrap(true)
        tooltipFrames[tip] = frame
    end
    return frame
end

function A:Tooltip(kind, tip, data)
    if self:Combat() or not self:On(tooltipSettings[kind]) then return end
    if not data or (issecretvalue and issecretvalue(data)) then return end
    local frame = tooltipFrames[tip]
    if frame and frame:IsShown() then return end
    local title = tip:GetLeftLine(1)
    if not title or not self:Plain(title:GetText()) then return end

    local id
    if kind == "npc" then
        id = npcID(data.guid)
    else
        id = self:ID(data.id)
        if not id and kind == "item" then
            local link = self:Plain(data.hyperlink)
            id = link and self:ID(tonumber(link:match("|Hitem:(%d+)") or link:match("^item:(%d+)")))
        end
    end
    if not id then return end
    local ru, _, ai = self:Lookup(kind, id)
    if not ru then return end

    frame = translationBlock(tip)
    local text = frame.text
    local spoken, hints = self:ReadingFor(ru)
    local label = self:Color(spoken)..(ai and " |cffaaaaaa[IA]|r" or "")
    for _, hint in ipairs(hints) do label = label.."\n|cffb8b8b8"..hint.."|r" end
    text:SetTextColor(1, .82, .42)
    text:SetWidth(0)
    text:SetText(label)
    local width = math.max(1, math.min(300, math.ceil(text:GetStringWidth())))
    text:SetWidth(width)
    frame:SetSize(width, math.max(1, math.ceil(text:GetStringHeight())))
    GameTooltip_InsertFrame(tip, frame, 1)
end

local function primaryData(tip)
    if tip ~= GameTooltip and tip ~= ItemRefTooltip and not isComparison(tip) then return end
    local info = tip:GetProcessingTooltipInfo()
    if info and info == tip:GetPrimaryTooltipInfo() then return info.tooltipData end
end

function A:InstallTooltips()
    local processor = TooltipDataProcessor
    if not processor or not processor.AddTooltipPostCall or not GameTooltip_InsertFrame
        or not Enum or not Enum.TooltipDataType then
        self.errors.tooltips = "Insertion des infobulles indisponible"
        return
    end
    local kinds = {}
    local comparisonManager = TooltipComparisonManager
    local comparisonHook = comparisonManager and comparisonManager.SetItemTooltip and hooksecurefunc
    if comparisonHook then
        -- ShoppingTooltip adds stat deltas after its item post-call.
        hooksecurefunc(comparisonManager, "SetItemTooltip", function(manager, primary)
            A:Safe("tooltip:comparison", function()
                local tip = comparisonTooltip(manager, primary)
                local data = tip and pendingComparison[tip]
                if not data then return end
                pendingComparison[tip] = nil
                if data == tip:GetPrimaryTooltipData() then
                    A:Tooltip("item", tip, data)
                    if not A:Combat() then tip:Show() end
                end
            end)
        end)
    end

    for name, kind in pairs({Item="item", Spell="spell", Unit="npc"}) do
        local dataType = Enum.TooltipDataType[name]
        if dataType ~= nil then
            kinds[dataType] = kind
            processor.AddTooltipPostCall(dataType, function(tip, data)
                A:Safe("tooltip:"..kind, function()
                    if A:Combat() or (issecretvalue and issecretvalue(data)) then return end
                    if not data or primaryData(tip) ~= data then return end
                    local frame = tooltipFrames[tip]
                    if frame and frame:IsShown() then return end
                    if kind == "item" and comparisonHook and isComparison(tip)
                        and not A:On("tooltipBelowTitle") then
                        pendingComparison[tip] = data
                    else
                        A:Tooltip(kind, tip, data)
                    end
                end)
            end)
        end
    end

    if processor.AddLinePostCall and processor.AllTypes then
        processor.AddLinePostCall(processor.AllTypes, function(tip)
            if not A:On("tooltipBelowTitle") or A:Combat() then return end
            A:Safe("tooltip:title", function()
                local data = primaryData(tip)
                if not data or (issecretvalue and issecretvalue(data)) or tip:NumLines() ~= 1 then return end
                local dataType = data.type
                if issecretvalue and issecretvalue(dataType) then return end
                local kind = kinds[dataType]
                if kind then A:Tooltip(kind, tip, data) end
            end)
        end)
    end
end
function A:Slash(msg)
    local cmd,arg=(msg or ""):match("^%s*(%S*)%s*(.-)%s*$"); cmd=cmd:lower()
    if cmd=="" or cmd=="aventure" or cmd=="adventure" then
        self:ShowTab("adventure")
    elseif cmd=="alphabet" then self:ShowTab("alphabet")
    elseif cmd=="entrainement" or cmd=="review" then self:ShowTab("practice")
    elseif cmd=="bibliotheque" or cmd=="lexique" then self:ShowTab("library")
    elseif self.frame and cmd=="hide" then self.frame:Hide()
    elseif cmd=="voices" then self:ListVoices()
    elseif cmd=="voice" then if arg=="auto" then self.db.settings.voiceID=nil; self:Print("Détection automatique.") elseif tonumber(arg) then self.db.settings.voiceID=tonumber(arg); self:Print("Voix sélectionnée : "..arg) else self:Print("/fru voice ID ou auto") end
    elseif cmd=="say" then self:Speak(arg)
    elseif cmd=="debug" then self:Debug()
    elseif cmd=="fonttest" then self:ShowTab("fonttest")
    elseif cmd=="phonetic" then self:PhoneticCommand(arg)
    elseif cmd=="quest" then
        local id = self:ID(tonumber(arg))
        if self:Combat() then return end
        if not id then self:Print("/fru quest ID"); return end
        local reading = self:GetQuestReading(id)
        if reading then self:ShowQuestReading(reading)
        else self:Print("Quête sans traduction disponible. Vérifie FRS v3 et le pack ruRU.") end
    else self:Print("/fru [aventure|alphabet|entrainement|bibliotheque|quest ID|voices|voice ID|say TEXTE|phonetic MOT|fonttest|debug|hide]") end
end

if A.eventFrame then
    A:Event("PLAYER_LOGIN",function()
        if not A.db then A:InitDB() end
        A:InstallTooltips()
        SLASH_FOREVERRUSSE1="/fru"; SLASH_FOREVERRUSSE2="/foreverrusse"
        SlashCmdList.FOREVERRUSSE=function(msg) A:Safe("slash",A.Slash,A,msg) end
        A:RefreshAdventureNotice()
    end)
    A:Event("QUEST_ACCEPTED",function(id) A:AdventureQuestAccepted(id) end)
    A:Event("QUEST_TURNED_IN",function(id)
        if A:AdventureQuestTurnedIn(id) then
            A:RefreshAdventure()
            A:RefreshAdventureNotice()
        end
    end)
    A:Event("PLAYER_REGEN_DISABLED",function()
        if A.frame then A.frame:Hide() end
        A:RefreshAdventureNotice()
    end)
    A:Event("PLAYER_REGEN_ENABLED",function() A:RefreshAdventureNotice() end)
end
