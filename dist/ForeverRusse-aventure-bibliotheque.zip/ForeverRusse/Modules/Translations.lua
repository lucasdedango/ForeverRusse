local _, A = ...
local methods={item="GetItemName",spell="GetSpellName",npc="GetNpcName",quest="GetQuest"}
function A:Provider()
    local db=ForeverRosettaStoneDB
    if type(db)=="table" and db.apiVersion==3 then return db end
end
function A:Lookup(kind,id,locale)
    id=self:ID(id); if not id then return end; locale=locale or "ruRU"
    local db=self:Provider(); local method=methods[kind]
    if db and method then
        local v=self:Safe("FRS:"..method,db[method],db,id,locale)
        if kind=="quest" and type(v)=="table" then return v,"FRS",v.hasAITranslation end
        v=self:Plain(v)
        if v and v~="" then return v,"FRS",self:Safe("FRS:AI",db.IsAITranslated,db,kind,id,locale) end
    end
    local fallback=locale=="ruRU" and self.fallback[kind] and self.fallback[kind][id]
    if fallback then return fallback,"lexique local" end
    if self.db then
        local k=kind..":"..id; local m=self.db.missing
        if not m[k] then local n=0; for _ in pairs(m) do n=n+1 end; if n<500 then m[k]=true end end
    end
end
