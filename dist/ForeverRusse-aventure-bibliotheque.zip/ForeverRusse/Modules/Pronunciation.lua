local _, A = ...
local data = A.pronunciationData
local acute = "́"
local maxMissing = 250
local missing, missingCount = {}, 0
local frenchLower = {["É"]="é", ["È"]="è", ["Ï"]="ï"}

local function unstress(cue)
    return (cue:lower():gsub("[\194-\244][\128-\191]*",frenchLower))
end

local function canonical(text)
    return text:gsub("ё","ё"):gsub("Ё","Ё"):gsub("й","й"):gsub("Й","Й")
end

local function split(text)
    local parts, words, word = {}, {}, {}
    local function flush()
        if #word == 0 then return end
        local raw = table.concat(word)
        local key = {}
        for c in A:Chars(raw) do
            key[#key+1] = A.letterMap[c] and A.letterMap[c][2] or c
        end
        local part = {text=raw, key=table.concat(key)}
        parts[#parts+1] = part
        words[#words+1] = part
        word = {}
    end
    for c in A:Chars(canonical(text)) do
        if A.letterMap[c] or (c == acute and #word > 0) then
            word[#word+1] = c
        else
            flush()
            parts[#parts+1] = {text=c}
        end
    end
    flush()
    return parts, words
end

local function find(key)
    local direct = data[key]
    if direct ~= nil then return direct end
    local plain = (key:gsub(acute,""))
    local row = data[plain]
    if row and plain ~= key then
        -- An explicit accent can identify a different homograph.
        if key ~= row[1] then return end
        return row
    end
end

local function withAccent(original, accented)
    if not accented then return original end
    local letters = {}
    for c in A:Chars((original:gsub(acute,""))) do letters[#letters+1] = c end
    local out, index = {}, 0
    for c in A:Chars(accented) do
        if c == acute then
            out[#out+1] = c
        else
            index = index + 1
            out[#out+1] = letters[index]
        end
    end
    return index == #letters and table.concat(out) or original
end

function A:Pronunciation(text, trackMissing)
    text = self:Plain(text)
    if not text then return end
    local parts, words = split(text)
    local result = {original=text, accented=canonical(text), quality="absent", origin="translittération"}
    if #words == 0 then return result end
    result.latin = self:Translit(canonical(text))
    local keys, contiguous, hasLatin = {}, true, false
    local seenWord, separator = false, ""
    for _, part in ipairs(parts) do
        if part.key then
            if seenWord and not separator:match("^[%s%-]+$") then contiguous = false end
            keys[#keys+1] = part.key
            seenWord, separator = true, ""
        elseif part.text:match("[%a%d]") then
            contiguous, hasLatin = false, true
        elseif seenWord then
            separator = separator..part.text
        end
    end
    local phrase = table.concat(keys," ")
    local row = contiguous and find(phrase)
    local ambiguous = contiguous and row == false
    if row then
        local i = 0
        for accented in row[1]:gmatch("%S+") do
            i = i+1
            if words[i] then words[i].accented = withAccent(words[i].text, accented) end
        end
        result.french, result.ipa, result.quality = row[2], row[3], row[4]
        result.estimated = row[4] == "estimé"
        result.origin = row[4] == "manuel" and "correction manuelle" or "RuTranscript"
    else
        local french, ipa, complete = {}, {}, not ambiguous
        for _, word in ipairs(words) do
            local entry = not ambiguous and find(word.key)
            if entry then
                word.accented = withAccent(word.text, entry[1])
                word.french = entry[2]
                french[#french+1], ipa[#ipa+1] = entry[2], entry[3]
                if entry[4] == "estimé" then result.estimated = true end
            else
                complete = false
                local key = word.key
                if trackMissing and missingCount < maxMissing and #key <= 80 and not missing[key] then
                    missing[key] = true
                    missingCount = missingCount + 1
                end
            end
        end
        if complete and hasLatin then
            local mixed, plain = {}, {}
            for i, part in ipairs(parts) do
                mixed[i] = part.french or part.text
                plain[i] = part.french and unstress(part.french) or part.text
            end
            result.partial, result.partialPlain = table.concat(mixed), table.concat(plain)
            result.quality, result.origin = "partiel", "segments russes"
        elseif complete then
            result.french, result.ipa = table.concat(french," "), table.concat(ipa," ")
            result.quality, result.origin = "assemblé", "formes isolées"
        elseif ambiguous then
            result.quality = "ambigu"
        end
    end
    local accented = {}
    for i, part in ipairs(parts) do accented[i] = part.accented or part.text end
    result.accented = table.concat(accented)
    return result
end

function A:RussianDisplay(text, pronunciation)
    if not self:On("hints") or not self:On("phoneticAccents") then return (text:gsub(acute,"")) end
    return pronunciation and pronunciation.accented or text
end

function A:PronunciationHints(pronunciation)
    local lines = {}
    if not pronunciation or not pronunciation.latin or not self:On("hints") then return lines end
    local showLatin = self:On("phoneticLatin")
    if self:On("phoneticFrench") then
        local cue = pronunciation.french
        if cue then
            if not self:On("phoneticStress") then
                cue = unstress(cue)
            end
            local prefix = pronunciation.quality == "manuel" and "" or "≈ "
            local suffix = pronunciation.estimated and " · accent estimé" or ""
            lines[#lines+1] = prefix..cue..suffix
        elseif pronunciation.partial then
            local partial = self:On("phoneticStress") and pronunciation.partial or pronunciation.partialPlain
            lines[#lines+1] = "≈ "..partial.." · segments russes"
        else
            showLatin = true
        end
    end
    if showLatin then lines[#lines+1] = "Lat. : "..pronunciation.latin end
    if self:On("phoneticIPA") and pronunciation.ipa then lines[#lines+1] = "/"..pronunciation.ipa.."/" end
    return lines
end

function A:ReadingFor(text)
    local entry = self:On("hints") and self:Pronunciation(text, true)
    return self:RussianDisplay(text, entry), self:PronunciationHints(entry)
end

function A:StudyReading(text)
    local entry = self:Pronunciation(text)
    if entry.french then
        local estimate = entry.estimated and " · accent estimé" or ""
        return entry.accented, "≈ "..entry.french..estimate
    end
    if entry.partial then return entry.accented, "≈ "..entry.partial.." · segments russes" end
    if entry.latin then return entry.accented, "Translittération : "..entry.latin end
    return entry.accented, ""
end

function A:MissingPronunciations()
    local words = {}
    for word in pairs(missing) do words[#words+1] = word end
    table.sort(words)
    return words
end

function A:PhoneticCommand(text)
    if text == "export" then
        self:ShowTab("phoneticExport")
        return
    end
    local entry = self:Pronunciation(text, true)
    if not entry or not entry.latin then self:Print("/fru phonetic MOT RUSSE · /fru phonetic export"); return end
    self:Print(entry.accented.." · "..entry.origin.." ("..entry.quality..")")
    if entry.french then self:Print(entry.french.." · /"..entry.ipa.."/")
    elseif entry.partial then self:Print(entry.partial)
    else self:Print("Lat. : "..entry.latin) end
end
